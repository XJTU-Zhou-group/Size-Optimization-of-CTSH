#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import xlrd
wb = xlrd.open_workbook('2222.xlsx')
sh = wb.sheet_by_name('Sheet3')
for i in range(0,sh.nrows):
    Num = sh.cell(i,0).value
    L = sh.cell(i,1).value
    H = sh.cell(i,2).value
    #�пڳߴ�
    #L=350
    #H=30
    l=L/2
    h=H/2
    openMdb(pathName='pinching_first(2).cae')
    #: The model database "E:\2023_3_CTSH�ߴ��Ż�\pinching_first(2).cae" has been opened.
    session.viewports['Viewport: 1'].setValues(displayedObject=None)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    d = p.datums
    t = p.MakeSketchTransform(sketchPlane=d[55], sketchUpEdge=d[54].axis2, 
        sketchPlaneSide=SIDE1, sketchOrientation=RIGHT, origin=(21.5, 0.0, 220.0))
    s = mdb.models['DL1-04_pressure-bigholder-thinwall'].ConstrainedSketch(
        name='__profile__', sheetSize=977.2, gridSpacing=24.43, transform=t)
    g, v, d1, c = s.geometry, s.vertices, s.dimensions, s.constraints
    s.setPrimaryObject(option=SUPERIMPOSE)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    p.projectReferencesOntoSketch(sketch=s, filter=COPLANAR_EDGES)
    s.ConstructionLine(point1=(0.0, 0.0), point2=(0.0, 67.1825000000559))
    s.VerticalConstraint(entity=g[2], addUndoState=False)
    s.ConstructionLine(point1=(0.0, 0.0), point2=(36.645, 0.0))
    s.HorizontalConstraint(entity=g[3], addUndoState=False)
    s.FixedConstraint(entity=g[2])
    s.FixedConstraint(entity=g[3])
    s.Line(point1=(0.0, h), point2=(l, h))
    s.HorizontalConstraint(entity=g[4], addUndoState=False)
    s.PerpendicularConstraint(entity1=g[2], entity2=g[4], addUndoState=False)
    s.CoincidentConstraint(entity1=v[0], entity2=g[2], addUndoState=False)
    #: 91.61
    s.ArcByCenterEnds(center=(l, 0.0), point1=(l, h), point2=(l+h, 0.0), direction=CLOCKWISE)
    s.CoincidentConstraint(entity1=v[2], entity2=g[3], addUndoState=False)
    s.copyMirror(mirrorLine=g[3], objectList=(g[5], g[4]))
    s.copyMirror(mirrorLine=g[2], objectList=(g[4], g[5], g[7], g[6]))
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    d2 = p.datums
    p.CutExtrude(sketchPlane=d2[55], sketchUpEdge=d2[54].axis2, 
        sketchPlaneSide=SIDE1, sketchOrientation=RIGHT, sketch=s, 
        flipExtrudeDirection=OFF)
    s.unsetPrimaryObject()
    del mdb.models['DL1-04_pressure-bigholder-thinwall'].sketches['__profile__']
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedFaces = f.getSequenceFromMask(mask=('[#1 ]', ), )
    d = p.datums
    p.PartitionFaceByDatumPlane(datumPlane=d[58], faces=pickedFaces)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedFaces = f.getSequenceFromMask(mask=('[#1 ]', ), )
    d2 = p.datums
    p.PartitionFaceByDatumPlane(datumPlane=d2[57], faces=pickedFaces)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedFaces = f.getSequenceFromMask(mask=('[#7 ]', ), )
    d = p.datums
    p.PartitionFaceByDatumPlane(datumPlane=d[77], faces=pickedFaces)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedFaces = f.getSequenceFromMask(mask=('[#3f ]', ), )
    d2 = p.datums
    p.PartitionFaceByDatumPlane(datumPlane=d2[76], faces=pickedFaces)

    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    e = p.edges
    p.DatumPointByMidPoint(point1=p.InterestingPoint(edge=e[3], rule=CENTER), 
        point2=p.InterestingPoint(edge=e[1], rule=CENTER))
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    v1, e1, d, n = p.vertices, p.edges, p.datums, p.nodes
    p.ReferencePoint(point=(0.0, 0.0, 430.0))
    p = mdb.models['DL1-04_pressure-bigholder-thinwall-Copy'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    session.viewports['Viewport: 1'].partDisplay.setValues(sectionAssignments=ON, 
        engineeringFeatures=ON)
    session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
        referenceRepresentation=OFF)
    p1 = mdb.models['DL1-04_pressure-bigholder-thinwall-Copy'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p1)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    r = p.referencePoints
    refPoints=(r[97], )
    region=regionToolset.Region(referencePoints=refPoints)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1'].engineeringFeatures.inertias['Inertia-1'].setValues(
        region=region)
    p1 = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-4']
    session.viewports['Viewport: 1'].setValues(displayedObject=p1)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#fff ]', ), )
    region = regionToolset.Region(faces=faces)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    p.SectionAssignment(region=region, sectionName='Section-3', offset=0.0, 
        offsetType=MIDDLE_SURFACE, offsetField='', 
        thicknessAssignment=FROM_SECTION)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    session.viewports['Viewport: 1'].setValues(displayedObject=a)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(
        optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    a.Instance(name='Part-1-1', part=p, dependent=ON)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-4']
    a.Instance(name='Part-4-1', part=p, dependent=ON)
    p1 = a.instances['Part-4-1']
    p1.translate(vector=(52.0305241933475, 0.0, 0.0))
    session.viewports['Viewport: 1'].view.fitView()
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    a.translate(instanceList=('Part-4-1', ), vector=(-52.030524, 0.0, 420.0))
    #: The instance Part-4-1 was translated by -52.030524, 0., 420. with respect to the assembly coordinate system
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(interactions=ON, 
        constraints=ON, connectors=ON, engineeringFeatures=ON)

    i1 = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly.allInstances['Part-1-1']
    leaf = dgm.LeafFromInstance(instances=(i1, ))
    session.viewports['Viewport: 1'].assemblyDisplay.displayGroup.remove(leaf=leaf)
    leaf = dgm.Leaf(leafType=DEFAULT_MODEL)
    session.viewports['Viewport: 1'].assemblyDisplay.displayGroup.replace(
        leaf=leaf)
    i1 = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly.allInstances['Part-4-1']
    leaf = dgm.LeafFromInstance(instances=(i1, ))
    session.viewports['Viewport: 1'].assemblyDisplay.displayGroup.remove(leaf=leaf)

    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-4-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#1 ]', ), )
    region1=regionToolset.Region(side1Edges=side1Edges1)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-1-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#a0000008 #2000 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].Tie(name='Constraint-1', 
        master=region1, slave=region2, positionToleranceMethod=COMPUTED, adjust=ON, 
        tieRotations=ON, thickness=ON)

    leaf = dgm.Leaf(leafType=DEFAULT_MODEL)
    session.viewports['Viewport: 1'].assemblyDisplay.displayGroup.replace(
        leaf=leaf)

    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    r1 = a.instances['Part-1-1'].referencePoints
    refPoints1=(r1[97], )
    region1=regionToolset.Region(referencePoints=refPoints1)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-1-1'].faces
    side2Faces1 = s1.getSequenceFromMask(mask=('[#8a1 ]', ), )
    region2=regionToolset.Region(side2Faces=side2Faces1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].Coupling(name='Constraint-2', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=KINEMATIC, localCsys=None, u1=ON, u2=ON, u3=ON, ur1=ON, 
        ur2=ON, ur3=ON)

    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    e1 = a.instances['Part-1-1'].edges
    a.ReferencePoint(point=a.instances['Part-1-1'].InterestingPoint(edge=e1[15], 
        rule=CENTER))

    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[202], )
    region1=regionToolset.Region(referencePoints=refPoints1)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-1-1'].faces
    side2Faces1 = s1.getSequenceFromMask(mask=('[#24c ]', ), )
    region2=regionToolset.Region(side2Faces=side2Faces1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].Coupling(name='Constraint-3', 
        controlPoint=region1, surface=region2, influenceRadius=WHOLE_SURFACE, 
        couplingType=KINEMATIC, localCsys=None, u1=ON, u2=ON, u3=ON, ur1=ON, 
        ur2=ON, ur3=ON)

    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='rotating2')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='deployment')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(loads=ON, bcs=ON, 
        predefinedFields=ON, interactions=OFF, constraints=OFF, 
        engineeringFeatures=OFF)

    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-1-1'].faces
    side1Faces1 = s1.getSequenceFromMask(mask=('[#512 ]', ), )
    region = regionToolset.Region(side1Faces=side1Faces1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].loads['Load-1'].setValues(
        region=region)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    r1 = a.referencePoints
    refPoints1=(r1[202], )
    region = regionToolset.Region(referencePoints=refPoints1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].EncastreBC(name='BC-1', 
        createStepName='rotating2', region=region, localCsys=None)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='deployment')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-1'].move(
        'rotating2', 'Initial')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-1'].deactivate(
        'deployment')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Initial')
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    r1 = a.instances['Part-1-1'].referencePoints
    refPoints1=(r1[97], )
    region = regionToolset.Region(referencePoints=refPoints1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].DisplacementBC(name='BC-2', 
        createStepName='Initial', region=region, u1=SET, u2=UNSET, u3=UNSET, 
        ur1=UNSET, ur2=SET, ur3=SET, amplitude=UNSET, distributionType=UNIFORM, 
        fieldName='', localCsys=None)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='rotating2')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-2'].setValuesInStep(
        stepName='rotating2', ur1=0.78, amplitude='folding-deployment')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='deployment')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-1'].reset(
        'deployment')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-2'].deactivate(
        'deployment')
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(loads=OFF, bcs=OFF, 
        predefinedFields=OFF, interactions=ON, constraints=ON, 
        engineeringFeatures=ON)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    f1 = a.instances['Part-4-1'].faces
    faces1 = f1.getSequenceFromMask(mask=('[#1 ]', ), )
    region2=regionToolset.Region(faces=faces1)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    r1 = a.instances['Part-4-1'].referencePoints
    refPoints1=(r1[18], )
    region1=regionToolset.Region(referencePoints=refPoints1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].RigidBody(name='Constraint-4', 
        refPointRegion=region1, bodyRegion=region2)
    a = mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    s1 = a.instances['Part-1-1'].edges
    side1Edges1 = s1.getSequenceFromMask(mask=('[#40088000 #80 ]', ), )
    region2=regionToolset.Region(side1Edges=side1Edges1)
    mdb.models['DL1-04_pressure-bigholder-thinwall'].constraints['Constraint-3'].setValues(
    surface=region2)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(loads=ON, bcs=ON, 
        predefinedFields=ON, interactions=OFF, constraints=OFF, 
        engineeringFeatures=OFF)
    session.viewports['Viewport: 1'].assemblyDisplay.setValues(mesh=ON, loads=OFF, 
        bcs=OFF, predefinedFields=OFF, connectors=OFF)
    session.viewports['Viewport: 1'].assemblyDisplay.meshOptions.setValues(
        meshTechnique=ON)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    session.viewports['Viewport: 1'].setValues(displayedObject=p)
    session.viewports['Viewport: 1'].partDisplay.setValues(sectionAssignments=OFF, 
        engineeringFeatures=OFF, mesh=ON)
    session.viewports['Viewport: 1'].partDisplay.meshOptions.setValues(
        meshTechnique=ON)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    p.generateMesh()

    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedRegions = f.getSequenceFromMask(mask=('[#fff ]', ), )
    p.deleteMesh(regions=pickedRegions)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    pickedRegions = f.getSequenceFromMask(mask=('[#fff ]', ), )
    p.setMeshControls(regions=pickedRegions, elemShape=QUAD, algorithm=MEDIAL_AXIS)
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    p.generateMesh()
    del mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1'].materialOrientations[0]
    p = mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1']
    f = p.faces
    faces = f.getSequenceFromMask(mask=('[#fff ]', ), )
    region = regionToolset.Region(faces=faces)
    orientation=None
    mdb.models['DL1-04_pressure-bigholder-thinwall'].parts['Part-1'].MaterialOrientation(
        region=region, orientationType=SYSTEM, axis=AXIS_2, localCsys=orientation, 
        fieldName='', additionalRotationType=ROTATION_NONE, angle=0.0, 
        additionalRotationField='')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-2'].reset(
        'deployment')
    mdb.models['DL1-04_pressure-bigholder-thinwall'].boundaryConditions['BC-2'].setValuesInStep(
        stepName='deployment', ur1=FREED)

    
    jobname = 'Job-'+str(int(Num))

    mdb.Job(name=jobname, model='DL1-04_pressure-bigholder-thinwall', 
        description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, 
        queue=None, memory=90, memoryUnits=PERCENTAGE, 
        explicitPrecision=DOUBLE_PLUS_PACK, nodalOutputPrecision=FULL, 
        echoPrint=OFF, modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, 
        userSubroutine='', scratch='', resultsFormat=ODB, 
        parallelizationMethodExplicit=DOMAIN, numDomains=60, 
        activateLoadBalancing=False, multiprocessingMode=DEFAULT, numCpus=60)

    mdb.saveAs(pathName=jobname)
        
    mdb.jobs[jobname].submit(consistencyChecking=OFF)
    mdb.jobs[jobname].waitForCompletion()

    Mdb()