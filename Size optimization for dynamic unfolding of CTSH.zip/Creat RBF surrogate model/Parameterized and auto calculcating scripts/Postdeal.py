# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
import section
import regionToolset
import displayGroupMdbToolset as dgm
import part
import material
import assembly
import step
import interaction
import load
import mesh
import optimization
import job
import sketch
import visualization
import xyPlot
import displayGroupOdbToolset as dgo
import connectorBehavior
import xlwt
'''
Time = []
AngleMax = []
for i in range(351,401):
    session.mdbData.summary()
    Jobname='Job-'+str(i)+'.odb'
    Linename='Job-'+str(i)
    o1 = session.openOdb(name=Jobname)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    session.linkedViewportCommands.setValues(_highlightLinkedViewports=False)
    odbName=session.viewports[session.currentViewportName].odbDisplay.name
    session.odbData[odbName].setValues(activeFrames=(('deployment', ('0:-1', )), ))
    odb = session.odbs[Jobname]
    xyList = xyPlot.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((
        'UR_ANTIALIASING', NODAL, ((COMPONENT, 'UR1'), )), ), nodeSets=(
        "ASSEMBLY_CONSTRAINT-2_REFERENCE_POINT", ))
    xyp = session.XYPlot(Linename)
    chartName = xyp.charts.keys()[0]
    chart = xyp.charts[chartName]
    curveList = session.curveSet(xyData=xyList)
    chart.setValues(curvesToPlot=curveList)
    session.charts[chartName].autoColor(lines=True, symbols=True)
    session.viewports['Viewport: 1'].setValues(displayedObject=xyp)

    #The name of curev
    curveName=chart.curves.keys()[0]
    x0 = chart.curves[curveName].data
    for i in range(0,len(x0)):
        if x0[i][1]<0:
            Time.append((x0[i-1][0]+x0[i][0])/2)
            break
    Angle=[]        
    for i in range(0,len(x0)):
        Angle.append(x0[i][1])
    AngleMax.append(abs(min(Angle)))

    session.xyDataObjects.changeKey(fromName=curveName, toName=Linename)
    del session.xyDataObjects[Linename]

wb= xlwt.Workbook() 
sht=wb.add_sheet("sheet1")
for i in range(0,len(Time)):
    name='Job-'+str(i+1)
    sht.write(i+1,0,name)
    sht.write(i+1,1,Time[i])
    sht.write(i+1,2,AngleMax[i])
wb.save('Time-AngleMax.xls')
'''


mass = []
for i in range(1,401):
    name = 'Job-'+str(i)+'.cae'
    openMdb(pathName=name)
    a=mdb.models['DL1-04_pressure-bigholder-thinwall'].rootAssembly
    b=a.getArea(a.instances['Part-1-1'].faces)
    c=b
    mass.append(c)
    
wb= xlwt.Workbook() 
sht=wb.add_sheet("sheet1")
for i in range(0,len(mass)):
    name='Job-'+str(i+1)
    #sht.write(i+1,0,name)
    #sht.write(i+1,1,Time[i])
    #sht.write(i+1,2,AngleMax[i])
    sht.write(i+1,3,mass[i])
wb.save('Time-AngleMax.xls')